﻿using UnityEngine;

/// <summary>
/// Created by Coral
/// this class exits the game
/// </summary>
public class ExitScript : MonoBehaviour {
	public void Exit() {
		Application.Quit();
	}
}